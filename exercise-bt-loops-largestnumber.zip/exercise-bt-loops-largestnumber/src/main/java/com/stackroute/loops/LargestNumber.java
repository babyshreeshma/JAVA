package com.stackroute.loops;
import java.util.Scanner;
public class LargestNumber {
    public static void main(String[] args) {
        new LargestNumber().inputAcceptor();
    }
    //write logic to get inputs from user and send inputs to inputValidator
    public void inputAcceptor() {
    	Scanner sc = new Scanner(System.in);
    	String input=sc.nextLine();
    	inputValidator(input);
        sc.close();
    }
    //write logic to validate inputs and send inputs to findLargestNumber
    public void inputValidator(String input) {
    	String[] str = input.split(" ", 2);
    	int N=Integer.parseInt(str[0]);
    	int D=Integer.parseInt(str[1]);
    	if(N<0 || D<0) {
    		outputPrinter("Give proper input not negative values");
    	}
    	else if(D>9) {
    		outputPrinter("Give proper input not digit greater than 9");
    	}
    	else if(N==0) {
    		outputPrinter("Give proper input not number(N) equals to zero");
    	}
    	else {
    	
    	outputPrinter(findLargestNumber(N,D));
    }
}
    //write logic to find largest number and return it
    public int findLargestNumber(int number, int digit) {
    	String c=Integer.toString(digit);
    	for(int L=number;L>0;--L)
    	{
    		if(Integer.toString(L).indexOf(c)==-1)
    		{
    			return L;
    		}
    		/*else {
    			 return -1;
    		}
    		*/
    	}
       return -1;
    }
    //write logic to print the given printStatement
    public void outputPrinter(Object printStatement) {
    	System.out.println(printStatement);
    	}
}