package com.stackroute.exception;


public class InsufficientFundException extends Exception {
}