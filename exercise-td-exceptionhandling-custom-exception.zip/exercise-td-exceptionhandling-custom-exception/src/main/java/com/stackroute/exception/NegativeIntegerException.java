package com.stackroute.exception;
public class NegativeIntegerException extends Exception{
}