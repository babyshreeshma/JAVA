package com.ust;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;



public class ResistercolourduoTest {

	    private static final String[] COLORS = {"black", "brown", "red", "orange", "yellow", "green", "blue", "violet", "grey", "white"};

	    @Test
	    public void testDecodeResistanceValue() {
	        String[] colors = {"black", "brown", "red", "orange", "yellow", "green", "blue", "violet", "grey", "white"};

	        String input = "brown-green-violet";
	        int expectedResult = 15;
	        int actualResult = Resistercolourduo.decodeResistanceValue(input, colors);
	        Assertions.assertEquals(expectedResult, actualResult);
	    }

	    @TestFactory
	    public Stream<DynamicTest> dynamicTestsWithDifferentInputs() {
	        String[] colors = {"black", "brown", "red", "orange", "yellow", "green", "blue", "violet", "grey", "white"};

	        List<String> inputList = Arrays.asList(
	                "black-yellow-red",
	                "orange-blue-white",
	                "green-grey",
	                "violet-violet-violet",
	                "red-green"
	        );

	        List<Integer> expectedResults = Arrays.asList(
	                4,
	                36,
	                58,
	                77,
	                25
	        );

	        return inputList.stream().map(input ->
	                DynamicTest.dynamicTest("Test decodeResistanceValue with input: " + input, () -> {
	                    int expected = expectedResults.get(inputList.indexOf(input));
	                    int actual = Resistercolourduo.decodeResistanceValue(input, colors);
	                    Assertions.assertEquals(expected, actual);
	                })
	        );
	    }

	    @Test
	    void testDecodeResistanceValue_TwoColors() {
	        String input = "brown-green";
	        int expected = 15;
	        int result = Resistercolourduo.decodeResistanceValue(input, COLORS);
	        assertEquals(expected, result);
	    }

	    @Test
	    void testDecodeResistanceValue_MoreThanTwoColors() {
	        String input = "brown-green-violet";
	        int expected = 15;
	        int result = Resistercolourduo.decodeResistanceValue(input, COLORS);
	        assertEquals(expected, result);
	    }

	    @Test
	    void testDecodeResistanceValue_LessThanTwoColors() {
	        String input = "green";
	        int expected = 5;
	        int result = Resistercolourduo.decodeResistanceValue(input, COLORS);
	        assertEquals(expected, result);
	    }

	  

	    @Test
	    void testDecodeResistanceValue_EmptyInput() {
	        String input = "";
	        int expected = 0;
	        int result = Resistercolourduo.decodeResistanceValue(input, COLORS);
	        assertEquals(expected, result);
	    }

	    @Test
	    void testDecodeResistanceValue_NullInput() {
	        String input = null;
	        int expected = 0;
	        int result = Resistercolourduo.decodeResistanceValue(input, COLORS);
	        assertEquals(expected, result);
	    }

	    @Test
	    void testDecodeResistanceValue_MixedCaseColors() {
	        String input = "Blue-YElloW";
	        int expected = 64;
	        int result = Resistercolourduo.decodeResistanceValue(input, COLORS);
	        assertEquals(expected, result);
	    }

	    @Test
	    void testDecodeResistanceValue_RepeatedColors() {
	        String input = "green-green-red";
	        int expected = 55;
	        int result = Resistercolourduo.decodeResistanceValue(input, COLORS);
	        assertEquals(expected, result);
	    }
	}

