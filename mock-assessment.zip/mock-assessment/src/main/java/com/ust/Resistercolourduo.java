package com.ust;

public class Resistercolourduo {
	    private static final String[] COLORS = {"black", "brown", "red", "orange", "yellow", "green", "blue", "violet", "grey", "white"};
	    /**
	     * Decodes a resistance value based on the input string and color codes.
	     *String input= {"black-brown"};
	     * @param  input   the input string containing the resistance colors separated by hyphen
	     * 
	     * @param  colors  an array of color codes used for decoding the resistance value
	     * @return         the decoded resistance value
	     */
	    
	    	
	    
	    public static int decodeResistanceValue(String input, String[] colors) {
	    	int rvalue=0;
	    	//String [] colors= {"black", "brown", "red", "orange", "yellow", "green", "blue", "violet", "grey", "white"};
	    	if(input=="" || input==null)
	    		return 0;
	    	
	    	String input1=input.toLowerCase();
	    	String [] clr=input1.split("-");
	    	for(int i=0;i<Math.min(clr.length, 2);i++) {
	    		int index=getColorIndex(clr[i], colors);
	    		if(index!=-1) {
	    			rvalue=rvalue*10+index;
	    		}
	    		
	    	}
	    	
	    	return rvalue;
	    }
	    /**
	     * Returns the index of the given color in the specified array of colors.
	     *
	     * @param  color  the color whose index needs to be found
	     * @param  colors the array of colors in which to search for the color index
	     * @return        the index of the color in the array, or 0 if the color is not found
	     */
	    
	    
	    private static int getColorIndex(String color, String[] colors) {
	    	
	    	for(int i=0;i<=colors.length;i++) {
    			if(colors[i].equalsIgnoreCase(color)) {
    				return i;
    			}
	    	}
    	
    	return -1;
	 
	    }
	}

	

