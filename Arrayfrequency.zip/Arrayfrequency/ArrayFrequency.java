package ust.exam;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ArrayFrequency {
		//Write a Java program to find the frequency of each element in an array.
		static void occurance(int arr[]) {
//			
//			boolean visited[]=new boolean[arr.length];
//			Arrays.fill(visited, false);
//			Arrays.sort(arr);
//			int count=0;
//			for(int j=0;j<arr.length;j++){
//				if(visited[j]==true)
//					continue;
//			
//			
//			for(int i=j+1;i<arr.length-1;i++) {
//				//System.out.print(arr[i]+"->");
//				if(arr[i]==arr[i]+1) {
//					visited[i]=true;
//					count++;
//				}
//				System.out.print(arr[i]+"->"+count+"\n");
//			}
//			}
			
//			Arrays.sort(arr);
//			int count =0;
//			int size=arr.length;
//			int arr2[]= new int[size];
//			for(int i=0;i<arr.length;i++) {
//				if(arr[i]==arr[i]+1) {
//						//count++;
////						for(int k=0;k<size;k++) {
////							//count++;
////							arr2[k]=arr2[k]+1;
////							System.out.println(+arr2[k]);
////						}
//				}
//				
//				System.out.println(arr[i]+"->");
//						
//			
//			}
			//return arr;
			
			Map<Integer,Integer> occurance= new HashMap<>();
			for(int num : arr) {
				if(occurance.containsKey(num)) {
					occurance.put(num, occurance.get(num)+1);
				}
				else {
					occurance.put(num, 1);
				}
			}
			for(Map.Entry<Integer,Integer>entry:occurance.entrySet()) {
				System.out.println(entry.getKey()+"->"+entry.getValue());
			}
			
			
			
			
		}
		
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the size:");
			int size=sc.nextInt();
			int [] arr=new int [size];
			System.out.println("Enter the array elements:");
			for(int i=0;i<size;i++) {
				arr[i]=sc.nextInt();
			}
		
		occurance(arr);
		}
	}



