package com.ust;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class IsogramTest {


	    @Test
	    void testValidIsogram() {
	        String word = "algorithm";
	        boolean expected = true;
	        boolean actual = Isogram.isIsogram(word);
	        assertEquals(expected, actual);
	    }

	    @Test
	    void testValidIsogramWithRepeatedLetters() {
	        String word = "subdermatoglyphic";
	        boolean expected = true;
	        boolean actual = Isogram.isIsogram(word);
	        assertEquals(expected, actual);
	    }

	    @Test
	    void testEmptyString() {
	        String word = "";
	        boolean expected = true;
	        boolean actual = Isogram.isIsogram(word);
	        assertEquals(expected, actual);
	    }

	    @Test
	    void testSingleCharacter() {
	        String word = "a";
	        boolean expected = true;
	        boolean actual = Isogram.isIsogram(word);
	        assertEquals(expected, actual);
	    }

	    @Test
	    void testWordWithSpacesAndHyphens() {
	        String word = "re-p eat ed";
	        boolean expected = false;
	        boolean actual = Isogram.isIsogram(word);
	        assertEquals(expected, actual);
	    }

	    @Test
	    void testWordWithUppercaseLetters() {
	        String word = "AbCDefG";
	        boolean expected = true;
	        boolean actual = Isogram.isIsogram(word);
	        assertEquals(expected, actual);
	    }

	  

	    @Test
	    void testNullWord() {
	        assertThrows(IllegalArgumentException.class, () -> {
	            Isogram.isIsogram(null);
	        });
	    }

	    @Test
	    void testReturnBooleanType() {
	        String word = "word";
	        boolean result = Isogram.isIsogram(word);
	        assertTrue(result);
	    }
	}

	


