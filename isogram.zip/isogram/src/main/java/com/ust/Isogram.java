

package com.ust;

import java.util.Arrays;

public class Isogram
{
	   /**
	 * Determines whether a given word is an isogram.
	 *
	 * @param  word the word to check for isogram status
	 * @return true if the word is an isogram, false otherwise
	 * @author Kirubakaran k
	 */
	
	public static boolean isIsogram(String word)  throws IllegalArgumentException{
		 if(word == null) {
			 throw new IllegalArgumentException("Error:");
		 }
	 
		
		
		boolean flag=true;
		word=word.toLowerCase();
		char[] ar = word.toCharArray();
		Arrays.sort(ar);
		
		for(int i=0;i<ar.length-1;++i)
		{
			if(ar[i]==ar[i+1])
			{
				flag = false;
			}
		}
		
		return flag;
	}
	
}