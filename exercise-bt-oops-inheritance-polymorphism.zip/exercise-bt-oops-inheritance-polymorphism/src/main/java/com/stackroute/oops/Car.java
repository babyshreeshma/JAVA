package com.stackroute.oops;
public class Car extends AbstractManufacturer implements Vehicle {
private String carType,modelName,name;
public Car(String name, String modelName, String carType) {
super(name,modelName,carType);
}
/*
Method returns maximum speed depending upon their types
For sports-250kmh
For sedan-190kmh
*/
@Override
public int maxSpeed(String carType) {
if(carType=="sports")
return 250;
else if(carType=="sedan")
return 190;
else
return 0;
}
/*
should return in the format : Car{Manufacturer name:'name',Model Name:'modelName',Type:'type'}
*/
@Override
public String getManufacturerInformation() {
// return "Author{name='" + name + "', country='" + country + "'}";
return "car{manufacturer name:" + getName() + ",model name:" + getModelName() + ",type:" + getType() + "}";
}
}
