package com.stackroute.oops;
public class VehicleService {
/*
create a Car object and return it
+createCar(String,String,String) : Car
+createBike(String,String,String) : Bike
+compareMaxSpeed(Vehicle,Vehicle) : int
*/
public Car createCar(String name, String modelName, String type) {
Car c= new Car(name,modelName,type);
return c;
}
/*
create a bike object and return it
*/
public Bike createBike(String name, String modelName, String type) {
Bike b= new Bike(name,modelName,type);
return b;
}
/*
Method should compare the speed only if the vehicle is of "SPORTS" type.
Method should return 0 when speeds are equal otherwise should return maximum vehicle speed.
Method returns -1 if the type is not "SPORTS"
*/
public int compareMaxSpeed(Vehicle first, Vehicle second) {
/*
Vehicle objects should be downcasted to their respective concrete types
*/
Car c;
Bike b;
if (first instanceof Car && second instanceof Bike) {
c = (Car) first;
b = (Bike) second;
if (c.maxSpeed("sports") == b.maxSpeed("sports") && c.getType().equals("sports")&& b.getType().equals("sports")) {
return 0;
} 
else if (c.maxSpeed("sports") != b.maxSpeed("sports") && c.getType().equals("sports")&& b.getType().equals("sports")) {
return Math.max(c.maxSpeed("sports"), b.maxSpeed("sports"));
}
}
return -1;
}
}
