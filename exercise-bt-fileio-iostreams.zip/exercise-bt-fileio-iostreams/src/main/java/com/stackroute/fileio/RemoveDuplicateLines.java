package com.stackroute.fileio;

import java.io.FileInputStream;
import java.io.*;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;
import java.io.IOException;
import java.util.Scanner;
import java.util.Set;

public class RemoveDuplicateLines {
    //write logic to read data from input.txt and  write result to output.txt
    public void removeDuplicateLines() throws IOException {
    	
    	Set<String> uniqueLines =new HashSet<>();
    	
    	//Read input file
    	FileInputStream file=new FileInputStream("input.txt");
    	Scanner sc=new Scanner(file);
    	while (sc.hasNextLine()) {
    		String line=sc.nextLine();
    		uniqueLines.add(line);
    	}
    	sc.close();
    	
    	//Write unique lines to output file
    	FileWriter fw=new FileWriter("output.txt");
    	for(String line : uniqueLines) {
    		fw.write(line+"\n");
    	}
    	fw.close();
    }
    
}
