package com.stackroute.collections;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
public class FruitsListService {
	public static List<String> addFruitsToList(String fruits) {
		List<String> fruitList = new ArrayList<>();
		Set<String> uniqueFruits = new HashSet<>();
		if (fruits != null && !fruits.isEmpty()) {
			String[] fruitArray = fruits.split(",");
			for (String fruit : fruitArray) {
				String trimmedFruit = fruit.trim();
				if (!uniqueFruits.contains(trimmedFruit) && fruitList.size() < 3) {
					fruitList.add(trimmedFruit);
					uniqueFruits.add(trimmedFruit);
				}
			}
		}
		return fruitList;
	}
	public static int searchFruitInList(List<String> fruitList, String fruit) {
		if (fruitList != null && !fruitList.isEmpty() && fruit != null) {
			for (int i = 0; i < fruitList.size(); i++) {
				if (fruitList.get(i).equals(fruit)) {
					return i;
				}
			}
		}
		return -1;
	}
	public static int searchFruitInListIgnoreCase(List<String> fruitList, String fruit) {
		if (fruitList != null && !fruitList.isEmpty() && fruit != null) {
			for (int i = 0; i < fruitList.size(); i++) {
				if (fruitList.get(i).equalsIgnoreCase(fruit)) {
					return i;
				}
			}
		}
		return -1;
	}
	public static void main(String[] args) {
		String fruits = "apple,mango,Cherry,apple,Cherry";
		List<String> fruitList = FruitsListService.addFruitsToList(fruits);
		System.out.println(fruitList); // Output: [apple, mango, Cherry]
		String fruitToSearch = "Mango";
		int index = FruitsListService.searchFruitInList(fruitList, fruitToSearch);
		System.out.println(index); // Output: -1 (Case-sensitive search)
		int indexIgnoreCase = FruitsListService.searchFruitInListIgnoreCase(fruitList, fruitToSearch);
		System.out.println(indexIgnoreCase); // Output: 1 (Case-insensitive search)
	}
}









