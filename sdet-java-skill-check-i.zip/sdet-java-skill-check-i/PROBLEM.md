## Problem Statement

    Amit is hosting a party and wants all guest to be given a new name to be used for a game.
    The new name should be created by swapping some or all of its characters.

    This new word must meet two criteria:

    1 - It must be greater than the original word ("lexicographically greater")
    2 - It must be the smallest word that meets the first condition

    If not possible to get a new name, display "not possible"


    e.g. If original name is "abcd" the new name will be "abdc" 

    some more samples - 

    hefg		hegf
    india		iniad
    bbb		not possible
    noida		oadin

    Write a method "GetGreaterName" to pass the name and return the greater name.
