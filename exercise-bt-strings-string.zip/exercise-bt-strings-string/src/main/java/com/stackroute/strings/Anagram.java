package com.stackroute.strings;
import java.util.Arrays;
//import java.lang.String;
import java.util.Scanner;
public class Anagram {
//write logic to check given two phrases are anagrams or not and return result
public String checkAnagrams(String phraseOne, String phraseTwo) {
//StringBuffer sb=new StringBuffer();
int n1=phraseOne.length();
int n2=phraseTwo.length();
char[] charPhraseOne =phraseOne.toCharArray();
char[] charPhraseTwo =phraseTwo.toCharArray();
Arrays.sort(charPhraseOne);
Arrays.sort(charPhraseTwo);
if(n1!=n2) {
return "Given phrases are not anagrams";
}
if(n1==0 || n2==0) {
return "Give proper input not empty phrases";
}
else if(Arrays.equals(charPhraseOne,charPhraseTwo)){
return "Given phrases are anagrams";
}
else
return "Given phrases are not anagrams";
}
public static void main(String [] args) {
Scanner sc= new Scanner(System.in);
String str1=sc.nextLine();
String str2=sc.nextLine();
Anagram ca=new Anagram();
//ca.checkAnagrams(str1,str2);
System.out.print(ca.checkAnagrams(str1,str2));
}
}
