package com.stackroute.arrays;
import java.util.Arrays;
import java.util.Scanner;
public class CheckingForConsecutiveNumbersApp {
    public static void main(String[] args) {
    	CheckingForConsecutiveNumbersApp check= new CheckingForConsecutiveNumbersApp();
    	check.readInput();
    }

    //write logic to get inputs from user and send inputs to inputValidator
    public void readInput() {
    	Scanner sc= new Scanner(System.in);
    	String input=sc.nextLine();
    	inputValidator(input);
    	sc.close();
    }

    //write logic to send inputs to checkStrongNumber
    public void inputValidator(String input) {
    
    	
    	boolean isConsecutive = checkForConsecutive(input);
		if(isConsecutive) {
			displayResult("Given numbers are Consecutive");
		}
		else {
			displayResult("Given numbers are not Consecutive");
		}
    }

	//write logic to check given numbers are consecutive or not and returns true if numbers are consecutive otherwise false
    public boolean checkForConsecutive(String input) {
    	
    	String[] str = input.split(","); 
    	 int size = str.length;
         int [] arr = new int [size];
         for(int i=0; i<size; i++) {
            arr[i] = Integer.parseInt(str[i]);
            
         }
    	
    	Arrays.sort(arr);
		for(int i=1;i<size;i++)
    	{
			
    		if(arr[i]-arr[i-1] !=1) {
    			
    					return false;
    			}
    	}
		return true;
    }

    //write logic to print the given printStatement
    public void displayResult(Object printStatement) {
    	System.out.println(printStatement);

    }
}
