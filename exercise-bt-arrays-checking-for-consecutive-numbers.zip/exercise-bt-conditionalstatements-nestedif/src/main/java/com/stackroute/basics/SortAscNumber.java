package com.stackroute.basics;

import java.util.Scanner;

public class SortAscNumber {

    public static void main(String[] args) {
        new SortAscNumber().getNumbers();
    }

    //get the numbers from user through console
    public void getNumbers() {
    	
    	Scanner s = new Scanner(System.in);
    	System.out.println(numberSorter(s.nextInt(),s.nextInt(),s.nextInt(),s.nextInt()));
  
    	s.close();
    }

    //logic to sort the numbers
    public String numberSorter(int firstNumber, int secondNumber, int thirdNumber, int fourthNumber) {
    	
    	        String result = "";

    	        if (firstNumber < secondNumber && firstNumber < thirdNumber && firstNumber < fourthNumber) {
    	            result += firstNumber + ",";
    	            if (secondNumber < thirdNumber && secondNumber < fourthNumber) {
    	                result += secondNumber + ",";
    	                if (thirdNumber < fourthNumber) {
    	                    result += thirdNumber + ",";
    	                }
    	                result += fourthNumber;
    	            } else if (thirdNumber < secondNumber && thirdNumber < fourthNumber) {
    	                result += thirdNumber + ",";
    	                if (secondNumber < fourthNumber) {
    	                    result += secondNumber + ",";
    	                }
    	                result += fourthNumber;
    	            } else {
    	                result += fourthNumber + ",";
    	                if (secondNumber < thirdNumber) {
    	                    result += secondNumber + ",";
    	                }
    	                result += thirdNumber;
    	            }
    	        } else if (secondNumber < firstNumber && secondNumber < thirdNumber && secondNumber < fourthNumber) {
    	            result += secondNumber + ",";
    	            if (firstNumber < thirdNumber && firstNumber < fourthNumber) {
    	                result += firstNumber + ",";
    	                if (thirdNumber < fourthNumber) {
    	                    result += thirdNumber + ",";
    	                }
    	                result += fourthNumber;
    	            } else if (thirdNumber < firstNumber && thirdNumber < fourthNumber) {
    	                result += thirdNumber + ",";
    	                if (firstNumber < fourthNumber) {
    	                    result += firstNumber + ",";
    	                }
    	                result += fourthNumber;
    	            } else {
    	                result += fourthNumber + ",";
    	                if (firstNumber < thirdNumber) {
    	                    result += firstNumber + ",";
    	                }
    	                result += thirdNumber;
    	            }
    	        } else if (thirdNumber < firstNumber && thirdNumber < secondNumber && thirdNumber < fourthNumber) {
    	            result += thirdNumber + ",";
    	            if (firstNumber < secondNumber && firstNumber < fourthNumber) {
    	                result += firstNumber + ",";
    	                if (secondNumber < fourthNumber) {
    	                    result += secondNumber + ",";
    	                }
    	                result += fourthNumber;
    	            } else if (secondNumber < firstNumber && secondNumber < fourthNumber) {
    	                result += secondNumber + ",";
    	                if (firstNumber < fourthNumber) {
    	                    result += firstNumber + ",";
    	                }
    	                result += fourthNumber;
    	            } else {
    	                result += fourthNumber + ",";
    	                if (firstNumber < secondNumber) {
    	                    result += firstNumber + ",";
    	                }
    	                result += secondNumber;
    	            }
    	        } else {
    	            result += fourthNumber + ",";
    	            if (firstNumber < secondNumber && firstNumber < thirdNumber) {
    	                result += firstNumber + ",";
    	                if (secondNumber < thirdNumber) {
    	                    result += secondNumber + ",";
    	                }
    	                result += thirdNumber;
    	            } else if (secondNumber < firstNumber && secondNumber < thirdNumber) {
    	                result += secondNumber + ",";
    	                if (firstNumber < thirdNumber) {
    	                    result += firstNumber + ",";
    	                }
    	                result += thirdNumber;
    	            } else {
    	                result += thirdNumber + ",";
    	                if (firstNumber < secondNumber) {
    	                    result += firstNumber + ",";
    	                }
    	                result += secondNumber;
    	            }
    	        }

    	        return "Sorted numbers: " + firstNumber + ", " + secondNumber + ", " + thirdNumber + ", " + fourthNumber;
    	    
    	

    	
    	
    }
}
